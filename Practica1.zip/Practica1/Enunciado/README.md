Autoras:

Paula Alemany 
Cynthia Tristán 

Realizado ejercicio opcional en LinearRegIt.py y midiendo el tiempo empleado en ambas versiones de LinearReg en el main :-)