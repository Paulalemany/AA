from MLP import MLP, target_gradient, costNN, MLP_backprop_predict
from MLP_Complete import MLP_Complete, MLP_backprop_predict_complete
from utils import load_data,load_weights,one_hot_encoding, accuracy
from public_test import checkNNGradients,MLP_test_step,SKLearn_test_step,Our_test_step
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import random
import numpy as np



"""
Test 1 to be executed in Main
"""
def gradientTest():
    checkNNGradients(costNN,target_gradient,0)
    checkNNGradients(costNN,target_gradient,1)


"""
Test 2 to be executed in Main
"""
def MLP_test(X_train,y_train, X_test, y_test):
    print("We assume that: random_state of train_test_split  = 0 alpha=1, num_iterations = 2000, test_size=0.33, seed=0 and epislom = 0.12 ")
    print("Test 1 Calculando para lambda = 0")
    MLP_test_step(MLP_backprop_predict,1,X_train,y_train,X_test,y_test,0,2000,0.92606,2000/10)
    print("Test 2 Calculando para lambda = 0.5")
    MLP_test_step(MLP_backprop_predict,1,X_train,y_train,X_test,y_test,0.5,2000,0.92545,2000/10)
    print("Test 3 Calculando para lambda = 1")
    MLP_test_step(MLP_backprop_predict,1,X_train,y_train,X_test,y_test,1,2000,0.92667,2000/10)
    
def SKLearn_test(X_train, Y_train, X_test, Y_test):
    n_hidden_neurons = 25 # numero de neuronas de la capa oculta
    lambda_ = 0.0
    alpha = 0.01 #tasa de aprendizaje
    num_ite = 2000 
    SKLearn_test_step(X_train, Y_train, X_test, Y_test, n_hidden_neurons, lambda_, alpha, num_ite)
    
    lambda_ = 0.5
    SKLearn_test_step(X_train, Y_train, X_test, Y_test, n_hidden_neurons, lambda_, alpha, num_ite)
    
    lambda_ = 1.0
    SKLearn_test_step(X_train, Y_train, X_test, Y_test, n_hidden_neurons, lambda_, alpha, num_ite)
    
def Our_test(X_train, y_train_encoded, X_test, Y_test):
    alpha = 1.0
    num_ite = 2000 
    lambda_ = 0.0
    Our_test_step(MLP_backprop_predict, X_train, y_train_encoded, X_test, Y_test, lambda_, alpha, num_ite)
    
    lambda_ = 0.5
    Our_test_step(MLP_backprop_predict, X_train, y_train_encoded, X_test, Y_test, lambda_, alpha, num_ite)
    
    lambda_ = 1.0
    Our_test_step(MLP_backprop_predict, X_train, y_train_encoded, X_test, Y_test, lambda_, alpha, num_ite)


def Our_test_Complete(X_train, y_train_encoded, X_test, Y_test):
    alpha = 1.0
    num_ite = 2000 
    lambda_ = 0.0
    Our_test_step(MLP_backprop_predict_complete, X_train, y_train_encoded, X_test, Y_test, lambda_, alpha, num_ite)
    
    lambda_ = 0.5
    Our_test_step(MLP_backprop_predict_complete, X_train, y_train_encoded, X_test, Y_test, lambda_, alpha, num_ite)
    
    lambda_ = 1.0
    Our_test_step(MLP_backprop_predict_complete, X_train, y_train_encoded, X_test, Y_test, lambda_, alpha, num_ite)


def main():
    print("Main program")

    # 400 es el tamaño del input (imagenes de 20 x 20 pixeles)
    # 25 es el tamaño de la capa oculta
    # 10 es el tamaño del output (Los 10 dígitos [0 - 9])

    print("----- EJERCICIO 1 -----")
    #appleJack = MLP(400, 25, 10)
    
    #Test 1
    print("----- EJERCICIO 2 -----")
    gradientTest()


    # Ejercicio 3
    print("----- EJERCICIO 3 -----")
    # Cargamos los datos reales
    X, Y = load_data('./Practica04Enunciado/Practica04Enunciado/data/ex3data1.mat')
    #C:\Users\Paula\source\repos\AA\Practica4\Practica04Enunciado\Practica04Enunciado\data\ex3data1.mat

    # Hay que coger una parte aleatoria de los datos, preferiblemente aleatorio a una sección para evitar sesgos
    # Cogemos una muestra aleatoria de los datos para entrenamiento y para los test
    X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, shuffle=True, random_state=42
)
    # Pasamos SOLO LOS DATOS DE ENTRENAMIENTO por el one_hot_encoding (la salida) para que la codificación coincida
    y_train_encoded = one_hot_encoding(Y_train)
    
    #Test 2
    # Pasamos el test
    MLP_test(X_train, y_train_encoded, X_test, Y_test)


    # Ejercicio 4: MLP de sklearn
    print("----- EJERCICIO 4 -----")
    # https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html
    
    # los test de MLP pasan con 3 lambas distintas (0, 0.5, 1) según estos parámetros, para lambda = 1:
    # MLP_test_step(MLP_backprop_predict,1,X_train,y_train,X_test,y_test, lambda,2000,0.92667,2000/10)
    alfa = 0.01, 
    num_ite = 2000
    baseLineAccuracy = 0.92667
    verbose = 2000/10
    
    SKLearn_test(X_train, Y_train, X_test, Y_test)
    
    # nuestra precisión
    Our_test(X_train, y_train_encoded, X_test, Y_test)

    
   
    print("----- EJERCICIO 5 (OPCIONAL) -----")
    # La red que estamos creando tiene 3 capas ocultas de 100, 50 y 25 neuronas cada 1
    # twilightsparkle = MLP_Complete(400,[100,50,25],10)
    
    #twilightsparkle = MLP_Complete(400, [25], 10)
    
    SKLearn_test(X_train, Y_train, X_test, Y_test)
    Our_test_Complete(X_train, y_train_encoded, X_test, Y_test)
    
    
main()